# food-management-website
a website that help use to manage the recipes and helps to view/shortlist recipes in a new manner
