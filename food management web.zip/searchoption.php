    <!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" 
    href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-
    beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
    <link rel="stylesheet" href="Sanchez_Bootstrap_index.css">
    </style>
    <title>Search recipe with ingridient</title>
  </head>
  <body>

    <!--NAVBAR-->
    <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
      <div class="container">
      <a class="navbar-brand" href="#"><h1>CHOOSE YOUR OPTION:-</h1></a>

    <!--Toggle Button-->
      <button class="navbar-toggler"
      data-toggle="collapse"
      data-target="#navbar"aria-controls="navbarTogglerDemo01" aria-
      expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span></button>

    <!--Navbar links-->
    <div class="collapse navbar-collapse" id="navbar">
    <ul class="nav navbar-nav">
    <li class="nav-item">
      <button type="button" class="btn btn-outline-success">
      <a class="nav-link" a href="search1.php"><h4>Search recipe with 1 ingridient</h4></a>
      </button>
    </li>
    <li class="nav-item">
      <button type="button" class="btn btn-outline-success">
      <a class="nav-link" href="search2.php"><h4>Search recipe with 2 ingridient</h4></a>
    </button>
    </li>
    
    </ul>
    </div>
    </div>
   </nav>

  <!--  <div id="content">
   <div class="container text-center">
   <div class="row">
    <div class="col-lg-12">

      <a class="btn btn-dark btn-lg" a 
     href="Sanchez_Bootstrap_about.html">Web 
     Developer</a>
      <a class="btn btn-dark btn-lg" a 
      href="Sanchez_Bootstrap_portfolio.html">Portfolio</a>
      <a class="btn btn-dark btn-lg" a 
      href="Sanchez_Bootstrap_contact.html">Contact</a>
      </<div>
      </div>
    </div>
  </div> -->


   <!--  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" 
    integrity="sha384-
    KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" 
    crossorigin="anonymous"></script>
    <script 


  src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-
    beta/js/bootstrap.min.js" integrity="sha384-
    h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" 
    crossorigin="anonymous"></script> -->
      </body>
    </html>